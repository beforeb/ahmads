/*
  # Initial Schema Setup
  
  1. Core Tables
    - Admin users management
    - Outlets and managers
    - Orders and tracking
    - Campaigns and feedback
    - System settings and audit logs
    
  2. Security
    - Row Level Security (RLS) enabled on all tables
    - Role-based access policies
    - Audit logging
*/

-- Create updated_at trigger function
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Admin Users
DO $$ BEGIN
  CREATE TABLE IF NOT EXISTS admin_users (
    id uuid PRIMARY KEY,
    role text NOT NULL CHECK (role IN ('super_admin', 'marketing', 'outlet_manager', 'finance', 'support')),
    permissions text[] NOT NULL DEFAULT '{}',
    last_login timestamptz,
    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now(),
    FOREIGN KEY (id) REFERENCES auth.users(id)
  );
EXCEPTION
  WHEN duplicate_table THEN NULL;
END $$;

DO $$ BEGIN
  ALTER TABLE admin_users ENABLE ROW LEVEL SECURITY;
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  CREATE POLICY "Admin users can view all admin users"
    ON admin_users
    FOR SELECT
    TO authenticated
    USING (auth.uid() IN (SELECT id FROM admin_users));
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  CREATE POLICY "Super admins can manage admin users"
    ON admin_users
    FOR ALL
    TO public
    USING (auth.uid() IN (SELECT id FROM admin_users WHERE role = 'super_admin'));
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  CREATE TRIGGER update_admin_users_updated_at
    BEFORE UPDATE ON admin_users
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at();
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

-- Outlets
DO $$ BEGIN
  CREATE TABLE IF NOT EXISTS outlets (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    name text NOT NULL,
    address text NOT NULL,
    latitude double precision NOT NULL,
    longitude double precision NOT NULL,
    is_open boolean DEFAULT true,
    opening_hours jsonb NOT NULL DEFAULT '{
      "monday": {"open": "08:00", "close": "22:00"},
      "tuesday": {"open": "08:00", "close": "22:00"},
      "wednesday": {"open": "08:00", "close": "22:00"},
      "thursday": {"open": "08:00", "close": "22:00"},
      "friday": {"open": "08:00", "close": "22:00"},
      "saturday": {"open": "08:00", "close": "22:00"},
      "sunday": {"open": "08:00", "close": "22:00"}
    }',
    phone text,
    email text,
    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now()
  );
EXCEPTION
  WHEN duplicate_table THEN NULL;
END $$;

DO $$ BEGIN
  ALTER TABLE outlets ENABLE ROW LEVEL SECURITY;
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  CREATE POLICY "Anyone can view outlets"
    ON outlets
    FOR SELECT
    TO public
    USING (true);
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  CREATE POLICY "Admins can manage outlets"
    ON outlets
    FOR ALL
    TO public
    USING (auth.uid() IN (SELECT id FROM admin_users));
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  CREATE TRIGGER update_outlets_updated_at
    BEFORE UPDATE ON outlets
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at();
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

-- Outlet Managers
DO $$ BEGIN
  CREATE TABLE IF NOT EXISTS outlet_managers (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    outlet_id uuid REFERENCES outlets(id) ON DELETE CASCADE,
    admin_id uuid REFERENCES admin_users(id) ON DELETE CASCADE,
    assigned_at timestamptz DEFAULT now(),
    UNIQUE(outlet_id, admin_id)
  );
EXCEPTION
  WHEN duplicate_table THEN NULL;
END $$;

DO $$ BEGIN
  ALTER TABLE outlet_managers ENABLE ROW LEVEL SECURITY;
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  CREATE POLICY "Admins can view outlet managers"
    ON outlet_managers
    FOR SELECT
    TO authenticated
    USING (auth.uid() IN (SELECT id FROM admin_users));
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  CREATE POLICY "Super admins can manage outlet managers"
    ON outlet_managers
    FOR ALL
    TO public
    USING (auth.uid() IN (SELECT id FROM admin_users WHERE role = 'super_admin'));
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

-- Orders
DO $$ BEGIN
  CREATE TABLE IF NOT EXISTS orders (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id uuid REFERENCES auth.users(id),
    outlet_id uuid REFERENCES outlets(id),
    status text NOT NULL CHECK (status IN ('pending', 'preparing', 'ready', 'delivering', 'completed', 'cancelled')),
    order_type text NOT NULL CHECK (order_type IN ('delivery', 'pickup', 'dine_in')),
    items jsonb NOT NULL,
    total_amount numeric NOT NULL,
    payment_status text NOT NULL CHECK (payment_status IN ('pending', 'paid', 'failed', 'refunded')),
    payment_method text,
    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now()
  );
EXCEPTION
  WHEN duplicate_table THEN NULL;
END $$;

DO $$ BEGIN
  ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  CREATE POLICY "Users can view their own orders"
    ON orders
    FOR SELECT
    TO authenticated
    USING (auth.uid() = user_id);
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  CREATE POLICY "Admins can manage orders"
    ON orders
    FOR ALL
    TO public
    USING (auth.uid() IN (SELECT id FROM admin_users));
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  CREATE TRIGGER update_orders_updated_at
    BEFORE UPDATE ON orders
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at();
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

-- Audit Logs
DO $$ BEGIN
  CREATE TABLE IF NOT EXISTS audit_logs (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    admin_id uuid REFERENCES admin_users(id),
    action text NOT NULL,
    details jsonb NOT NULL,
    ip_address text,
    created_at timestamptz DEFAULT now()
  );
EXCEPTION
  WHEN duplicate_table THEN NULL;
END $$;

DO $$ BEGIN
  ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  CREATE POLICY "Admins can view audit logs"
    ON audit_logs
    FOR SELECT
    TO authenticated
    USING (auth.uid() IN (SELECT id FROM admin_users));
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

-- System Settings
DO $$ BEGIN
  CREATE TABLE IF NOT EXISTS system_settings (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    key text UNIQUE NOT NULL,
    value jsonb NOT NULL,
    updated_by uuid REFERENCES admin_users(id),
    updated_at timestamptz DEFAULT now()
  );
EXCEPTION
  WHEN duplicate_table THEN NULL;
END $$;

DO $$ BEGIN
  ALTER TABLE system_settings ENABLE ROW LEVEL SECURITY;
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  CREATE POLICY "Anyone can view system settings"
    ON system_settings
    FOR SELECT
    TO public
    USING (true);
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  CREATE POLICY "Super admins can manage system settings"
    ON system_settings
    FOR ALL
    TO public
    USING (auth.uid() IN (SELECT id FROM admin_users WHERE role = 'super_admin'));
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

-- Campaigns
DO $$ BEGIN
  CREATE TABLE IF NOT EXISTS campaigns (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    title text NOT NULL,
    description text,
    type text NOT NULL CHECK (type IN ('discount', 'promotion', 'reward')),
    value numeric NOT NULL,
    start_date timestamptz NOT NULL,
    end_date timestamptz NOT NULL,
    target_users uuid[],
    target_outlets uuid[],
    minimum_spend numeric,
    max_redemptions integer,
    current_redemptions integer DEFAULT 0,
    status text NOT NULL CHECK (status IN ('active', 'scheduled', 'ended')),
    created_by uuid REFERENCES admin_users(id),
    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now()
  );
EXCEPTION
  WHEN duplicate_table THEN NULL;
END $$;

DO $$ BEGIN
  ALTER TABLE campaigns ENABLE ROW LEVEL SECURITY;
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  CREATE POLICY "Anyone can view active campaigns"
    ON campaigns
    FOR SELECT
    TO public
    USING (status = 'active' AND CURRENT_TIMESTAMP BETWEEN start_date AND end_date);
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  CREATE POLICY "Marketing admins can manage campaigns"
    ON campaigns
    FOR ALL
    TO public
    USING (auth.uid() IN (SELECT id FROM admin_users WHERE role IN ('super_admin', 'marketing')));
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  CREATE TRIGGER update_campaigns_updated_at
    BEFORE UPDATE ON campaigns
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at();
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

-- Customer Feedback
DO $$ BEGIN
  CREATE TABLE IF NOT EXISTS customer_feedback (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id uuid REFERENCES auth.users(id),
    order_id uuid REFERENCES orders(id),
    type text NOT NULL CHECK (type IN ('rating', 'complaint', 'suggestion')),
    content text NOT NULL,
    rating integer CHECK (rating >= 1 AND rating <= 5),
    status text NOT NULL DEFAULT 'new' CHECK (status IN ('new', 'in_progress', 'resolved')),
    assigned_to uuid REFERENCES admin_users(id),
    response text,
    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now()
  );
EXCEPTION
  WHEN duplicate_table THEN NULL;
END $$;

DO $$ BEGIN
  ALTER TABLE customer_feedback ENABLE ROW LEVEL SECURITY;
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  CREATE POLICY "Users can view their own feedback"
    ON customer_feedback
    FOR SELECT
    TO authenticated
    USING (auth.uid() = user_id);
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  CREATE POLICY "Support admins can manage feedback"
    ON customer_feedback
    FOR ALL
    TO public
    USING (auth.uid() IN (SELECT id FROM admin_users WHERE role IN ('super_admin', 'support')));
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  CREATE TRIGGER update_customer_feedback_updated_at
    BEFORE UPDATE ON customer_feedback
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at();
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

-- Order Status History
DO $$ BEGIN
  CREATE TABLE IF NOT EXISTS order_status_history (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id uuid REFERENCES orders(id) ON DELETE CASCADE,
    status text NOT NULL,
    updated_by uuid REFERENCES admin_users(id),
    notes text,
    created_at timestamptz DEFAULT now()
  );
EXCEPTION
  WHEN duplicate_table THEN NULL;
END $$;

DO $$ BEGIN
  ALTER TABLE order_status_history ENABLE ROW LEVEL SECURITY;
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  CREATE POLICY "Users can view their order history"
    ON order_status_history
    FOR SELECT
    TO authenticated
    USING (order_id IN (SELECT id FROM orders WHERE user_id = auth.uid()));
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  CREATE POLICY "Admins can manage order history"
    ON order_status_history
    FOR ALL
    TO public
    USING (auth.uid() IN (SELECT id FROM admin_users));
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;