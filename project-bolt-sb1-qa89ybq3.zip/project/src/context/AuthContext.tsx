import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, AuthState } from '../types';

// Mock authentication for demo purposes
// In a real app, this would use Firebase or another auth provider
const mockUsers: User[] = [
  {
    id: '1',
    email: 'user@example.com',
    name: 'Ahmad Customer',
    phone: '+60123456789',
    points: 240,
    referralCode: 'AHMAD123',
    checkInDates: [new Date().toISOString().split('T')[0]],
  },
];

interface AuthContextType extends AuthState {
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  register: (email: string, password: string, name: string, phone?: string, referralCode?: string) => Promise<void>;
  updatePoints: (points: number) => void;
  checkIn: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AuthState>({
    user: null,
    isLoading: true,
    error: null,
  });

  useEffect(() => {
    // Check for saved session
    const savedUser = localStorage.getItem('ahmads_user');
    if (savedUser) {
      setState({
        user: JSON.parse(savedUser),
        isLoading: false,
        error: null,
      });
    } else {
      setState(prev => ({ ...prev, isLoading: false }));
    }
  }, []);

  const login = async (email: string, password: string) => {
    setState(prev => ({ ...prev, isLoading: true, error: null }));
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 800));
      
      const user = mockUsers.find(u => u.email === email);
      
      if (!user) {
        throw new Error('User not found');
      }
      
      // In a real app, you would verify password here
      localStorage.setItem('ahmads_user', JSON.stringify(user));
      
      setState({
        user,
        isLoading: false,
        error: null,
      });
    } catch (error) {
      setState({
        user: null,
        isLoading: false,
        error: error instanceof Error ? error.message : 'An unknown error occurred',
      });
    }
  };

  const register = async (email: string, password: string, name: string, phone?: string, referralCode?: string) => {
    setState(prev => ({ ...prev, isLoading: true, error: null }));
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 800));
      
      // Check if user already exists
      if (mockUsers.some(u => u.email === email)) {
        throw new Error('User already exists');
      }
      
      // Generate a random ID for the new user
      const id = Math.random().toString(36).substring(2, 11);
      
      // Create new user
      const newUser: User = {
        id,
        email,
        name,
        phone,
        points: 0,
        referralCode: 'AH' + Math.random().toString(36).substring(2, 7).toUpperCase(),
        referredBy: referralCode,
        checkInDates: [new Date().toISOString().split('T')[0]],
      };
      
      mockUsers.push(newUser);
      
      localStorage.setItem('ahmads_user', JSON.stringify(newUser));
      
      setState({
        user: newUser,
        isLoading: false,
        error: null,
      });
    } catch (error) {
      setState({
        user: null,
        isLoading: false,
        error: error instanceof Error ? error.message : 'An unknown error occurred',
      });
    }
  };

  const logout = () => {
    localStorage.removeItem('ahmads_user');
    setState({
      user: null,
      isLoading: false,
      error: null,
    });
  };

  const updatePoints = (points: number) => {
    if (!state.user) return;
    
    const updatedUser = {
      ...state.user,
      points: state.user.points + points,
    };
    
    localStorage.setItem('ahmads_user', JSON.stringify(updatedUser));
    
    setState(prev => ({
      ...prev,
      user: updatedUser,
    }));
  };

  const checkIn = () => {
    if (!state.user) return;
    
    const today = new Date().toISOString().split('T')[0];
    
    // Check if user already checked in today
    if (state.user.checkInDates.includes(today)) return;
    
    const updatedUser = {
      ...state.user,
      points: state.user.points + 10, // Add 10 points for check-in
      checkInDates: [...state.user.checkInDates, today],
    };
    
    localStorage.setItem('ahmads_user', JSON.stringify(updatedUser));
    
    setState(prev => ({
      ...prev,
      user: updatedUser,
    }));
  };

  return (
    <AuthContext.Provider value={{ ...state, login, logout, register, updatePoints, checkIn }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}