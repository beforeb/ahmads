import { create } from 'zustand';
import { Cart, CartItem, MenuItem, Outlet, Address } from '../types';

interface CartStore {
  cart: Cart;
  addItem: (item: MenuItem, quantity: number, selectedOptions: CartItem['selectedOptions']) => void;
  removeItem: (id: string) => void;
  updateQuantity: (id: string, quantity: number) => void;
  setOrderType: (type: 'dine-in' | 'delivery') => void;
  setTableNumber: (number: string) => void;
  setDeliveryAddress: (address: Address) => void;
  setOutlet: (outlet: Outlet) => void;
  clearCart: () => void;
  applyPoints: (points: number) => void;
  calculateTotals: () => void;
}

const initialCart: Cart = {
  items: [],
  orderType: 'dine-in',
  outlet: null,
  subtotal: 0,
  discount: 0,
  total: 0,
};

export const useCartStore = create<CartStore>((set, get) => ({
  cart: initialCart,
  
  addItem: (item, quantity, selectedOptions) => {
    set((state) => {
      // Check if item is already in cart
      const existingItemIndex = state.cart.items.findIndex(
        (cartItem) => 
          cartItem.menuItemId === item.id && 
          JSON.stringify(cartItem.selectedOptions) === JSON.stringify(selectedOptions)
      );
      
      let newItems;
      
      if (existingItemIndex >= 0) {
        // Update quantity if item exists
        newItems = [...state.cart.items];
        newItems[existingItemIndex] = {
          ...newItems[existingItemIndex],
          quantity: newItems[existingItemIndex].quantity + quantity,
        };
      } else {
        // Add new item
        const cartItem: CartItem = {
          id: Math.random().toString(36).substring(2, 11),
          menuItemId: item.id,
          name: item.name,
          price: item.discountPrice || item.price,
          quantity,
          image: item.image,
          selectedOptions,
        };
        
        newItems = [...state.cart.items, cartItem];
      }
      
      const newCart = {
        ...state.cart,
        items: newItems,
      };
      
      // Recalculate totals
      const subtotal = newItems.reduce((total, item) => {
        const itemTotal = item.price * item.quantity;
        const optionsTotal = item.selectedOptions.reduce(
          (sum, option) => sum + option.price * item.quantity, 
          0
        );
        return total + itemTotal + optionsTotal;
      }, 0);
      
      return {
        cart: {
          ...newCart,
          subtotal,
          total: subtotal - newCart.discount,
        },
      };
    });
  },
  
  removeItem: (id) => {
    set((state) => {
      const newItems = state.cart.items.filter((item) => item.id !== id);
      
      const newCart = {
        ...state.cart,
        items: newItems,
      };
      
      // Recalculate totals
      const subtotal = newItems.reduce((total, item) => {
        const itemTotal = item.price * item.quantity;
        const optionsTotal = item.selectedOptions.reduce(
          (sum, option) => sum + option.price * item.quantity, 
          0
        );
        return total + itemTotal + optionsTotal;
      }, 0);
      
      return {
        cart: {
          ...newCart,
          subtotal,
          total: subtotal - newCart.discount,
        },
      };
    });
  },
  
  updateQuantity: (id, quantity) => {
    set((state) => {
      const newItems = state.cart.items.map((item) => 
        item.id === id ? { ...item, quantity } : item
      );
      
      const newCart = {
        ...state.cart,
        items: newItems,
      };
      
      // Recalculate totals
      const subtotal = newItems.reduce((total, item) => {
        const itemTotal = item.price * item.quantity;
        const optionsTotal = item.selectedOptions.reduce(
          (sum, option) => sum + option.price * item.quantity, 
          0
        );
        return total + itemTotal + optionsTotal;
      }, 0);
      
      return {
        cart: {
          ...newCart,
          subtotal,
          total: subtotal - newCart.discount,
        },
      };
    });
  },
  
  setOrderType: (type) => {
    set((state) => ({
      cart: {
        ...state.cart,
        orderType: type,
      },
    }));
  },
  
  setTableNumber: (number) => {
    set((state) => ({
      cart: {
        ...state.cart,
        tableNumber: number,
      },
    }));
  },
  
  setDeliveryAddress: (address) => {
    set((state) => ({
      cart: {
        ...state.cart,
        deliveryAddress: address,
      },
    }));
  },
  
  setOutlet: (outlet) => {
    set((state) => ({
      cart: {
        ...state.cart,
        outlet,
      },
    }));
  },
  
  clearCart: () => {
    set({
      cart: initialCart,
    });
  },
  
  applyPoints: (points) => {
    const pointsValue = points / 100; // 100 points = RM1
    set((state) => ({
      cart: {
        ...state.cart,
        discount: pointsValue,
        total: state.cart.subtotal - pointsValue,
      },
    }));
  },
  
  calculateTotals: () => {
    set((state) => {
      const subtotal = state.cart.items.reduce((total, item) => {
        const itemTotal = item.price * item.quantity;
        const optionsTotal = item.selectedOptions.reduce(
          (sum, option) => sum + option.price * item.quantity, 
          0
        );
        return total + itemTotal + optionsTotal;
      }, 0);
      
      return {
        cart: {
          ...state.cart,
          subtotal,
          total: subtotal - state.cart.discount,
        },
      };
    });
  },
}));