import { useState } from 'react';
import { TopBar, Navbar } from '../components/layout/Navbar';
import { Card, CardContent } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import {
  User,
  CreditCard,
  MapPin,
  Settings,
  LogOut,
  ChevronRight,
  Ticket,
  Gift,
  Phone,
  Mail,
  HelpCircle,
} from 'lucide-react';

export default function AccountPage() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [logoutLoading, setLogoutLoading] = useState(false);
  
  const handleLogout = async () => {
    setLogoutLoading(true);
    await new Promise(resolve => setTimeout(resolve, 500)); // Simulate API call
    logout();
    setLogoutLoading(false);
    navigate('/login');
  };
  
  if (!user) {
    return (
      <div className="min-h-screen bg-neutral-50 pb-20">
        <TopBar title="Account" />
        
        <div className="pt-14 px-4 flex flex-col items-center justify-center h-[80vh]">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold mb-2">Welcome to Ahmads+</h2>
            <p className="text-neutral-500">Sign in to access your account</p>
          </div>
          
          <div className="w-full space-y-3">
            <Button
              fullWidth
              size="lg"
              onClick={() => navigate('/login')}
            >
              Login
            </Button>
            <Button
              fullWidth
              size="lg"
              variant="outline"
              onClick={() => navigate('/register')}
            >
              Create Account
            </Button>
          </div>
        </div>
        
        <Navbar />
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-neutral-50 pb-20">
      <TopBar title="Account" />
      
      <div className="pt-14 px-4">
        {/* User Profile */}
        <div className="bg-primary-600 rounded-lg p-5 my-4 text-white">
          <div className="flex items-center mb-3">
            <div className="w-14 h-14 bg-white rounded-full flex items-center justify-center">
              <User className="w-8 h-8 text-primary-600" />
            </div>
            <div className="ml-4">
              <h2 className="font-bold text-lg">{user.name}</h2>
              <p className="text-sm opacity-90">{user.phone || user.email}</p>
            </div>
          </div>
          
          <div className="bg-white bg-opacity-20 p-3 rounded-lg flex justify-between items-center">
            <div>
              <p className="text-sm opacity-80">Ahmads+ Points</p>
              <p className="font-bold text-xl">{user.points} points</p>
            </div>
            <button 
              className="bg-white text-primary-600 px-3 py-1 rounded-lg text-sm font-semibold"
              onClick={() => navigate('/rewards')}
            >
              Redeem
            </button>
          </div>
        </div>
        
        {/* Account Section */}
        <div className="space-y-4">
          <Card>
            <CardContent className="p-0">
              <MenuItem
                icon={<CreditCard className="w-5 h-5" />}
                title="Payment Methods"
                onClick={() => navigate('/payment-methods')}
              />
              <MenuItem
                icon={<MapPin className="w-5 h-5" />}
                title="Saved Addresses"
                onClick={() => navigate('/addresses')}
              />
              <MenuItem
                icon={<Ticket className="w-5 h-5" />}
                title="Vouchers"
                onClick={() => navigate('/vouchers')}
              />
              <MenuItem
                icon={<Gift className="w-5 h-5" />}
                title="Rewards & Points"
                onClick={() => navigate('/rewards')}
                noBorder
              />
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-0">
              <MenuItem
                icon={<Settings className="w-5 h-5" />}
                title="Settings"
                onClick={() => navigate('/settings')}
              />
              <MenuItem
                icon={<Phone className="w-5 h-5" />}
                title="Contact Us"
                onClick={() => navigate('/contact')}
              />
              <MenuItem
                icon={<HelpCircle className="w-5 h-5" />}
                title="Help & FAQ"
                onClick={() => navigate('/help')}
                noBorder
              />
            </CardContent>
          </Card>
          
          <Button
            fullWidth
            variant="outline"
            className="border-error-500 text-error-500 hover:bg-error-50"
            leftIcon={<LogOut className="w-5 h-5" />}
            isLoading={logoutLoading}
            onClick={handleLogout}
          >
            Logout
          </Button>
          
          <p className="text-center text-neutral-400 text-xs mt-6">
            Ahmads+ v1.0.0
          </p>
        </div>
      </div>
      
      <Navbar />
    </div>
  );
}

interface MenuItemProps {
  icon: React.ReactNode;
  title: string;
  subtitle?: string;
  onClick: () => void;
  noBorder?: boolean;
}

function MenuItem({ icon, title, subtitle, onClick, noBorder = false }: MenuItemProps) {
  return (
    <button
      className={`w-full flex items-center justify-between p-4 ${
        !noBorder ? 'border-b border-neutral-100' : ''
      }`}
      onClick={onClick}
    >
      <div className="flex items-center">
        <div className="text-neutral-500 mr-3">{icon}</div>
        <div className="text-left">
          <p className="font-medium">{title}</p>
          {subtitle && <p className="text-sm text-neutral-500">{subtitle}</p>}
        </div>
      </div>
      <ChevronRight className="w-5 h-5 text-neutral-400" />
    </button>
  );
}