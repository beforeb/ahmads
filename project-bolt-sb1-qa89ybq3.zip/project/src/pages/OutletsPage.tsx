import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { TopBar } from '../components/layout/Navbar';
import { Card, CardContent } from '../components/ui/Card';
import { Input } from '../components/ui/Input';
import { Button } from '../components/ui/Button';
import { useCartStore } from '../store/cartStore';
import { outlets, getNearestOutlets } from '../data/outlets';
import { Outlet } from '../types';
import { MapPin, Search, Navigation, Clock, ChevronLeft } from 'lucide-react';

export default function OutletsPage() {
  const navigate = useNavigate();
  const setOutlet = useCartStore(state => state.setOutlet);
  const [nearestOutlets, setNearestOutlets] = useState<Outlet[]>([]);
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  
  useEffect(() => {
    // Get user's location
    if (navigator.geolocation) {
      setIsLoading(true);
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setUserLocation({ latitude, longitude });
          setNearestOutlets(getNearestOutlets(latitude, longitude));
          setIsLoading(false);
        },
        (error) => {
          console.error('Error getting location:', error);
          setNearestOutlets(outlets);
          setIsLoading(false);
        }
      );
    } else {
      setNearestOutlets(outlets);
    }
  }, []);
  
  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
  };
  
  const handleSelectOutlet = (outlet: Outlet) => {
    setOutlet(outlet);
    navigate(-1);
  };
  
  const filteredOutlets = searchQuery
    ? outlets.filter(outlet => 
        outlet.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        outlet.address.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : nearestOutlets;
  
  return (
    <div className="min-h-screen bg-neutral-50">
      <TopBar title="Select Outlet" />
      
      <div className="pt-14 px-4 pb-20">
        <div className="flex items-center my-4">
          <button 
            className="mr-3 p-2"
            onClick={() => navigate(-1)}
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          
          <Input
            placeholder="Search outlets..."
            value={searchQuery}
            onChange={handleSearch}
            leftIcon={<Search className="w-5 h-5 text-neutral-400" />}
          />
        </div>
        
        {isLoading ? (
          <div className="flex flex-col items-center justify-center h-64">
            <p className="text-neutral-500 mb-2">Finding nearest outlets...</p>
            <div className="w-8 h-8 border-4 border-primary-200 border-t-primary-600 rounded-full animate-spin"></div>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredOutlets.length > 0 ? (
              filteredOutlets.map((outlet) => (
                <Card key={outlet.id}>
                  <CardContent className="p-4">
                    <div className="flex justify-between">
                      <div>
                        <h3 className="font-semibold">{outlet.name}</h3>
                        <p className="text-sm text-neutral-500 mt-1">{outlet.address}</p>
                        
                        <div className="flex items-center mt-2">
                          <Clock className="w-4 h-4 text-neutral-400 mr-1" />
                          <span className="text-xs text-neutral-500">{outlet.openingHours}</span>
                          
                          {outlet.distance && (
                            <>
                              <span className="mx-2 text-neutral-300">|</span>
                              <Navigation className="w-4 h-4 text-neutral-400 mr-1" />
                              <span className="text-xs text-neutral-500">
                                {outlet.distance.toFixed(1)} km away
                              </span>
                            </>
                          )}
                        </div>
                      </div>
                      
                      <Button
                        variant={outlet.isOpen ? 'primary' : 'outline'}
                        disabled={!outlet.isOpen}
                        onClick={() => handleSelectOutlet(outlet)}
                      >
                        {outlet.isOpen ? 'Select' : 'Closed'}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <div className="text-center py-8">
                <MapPin className="w-12 h-12 text-neutral-300 mx-auto mb-2" />
                <p className="text-neutral-500">No outlets found matching "{searchQuery}"</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}