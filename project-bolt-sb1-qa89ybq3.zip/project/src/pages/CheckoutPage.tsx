import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { TopBar } from '../components/layout/Navbar';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Card, CardContent } from '../components/ui/Card';
import { useCartStore } from '../store/cartStore';
import { useAuth } from '../context/AuthContext';
import { createOrder } from '../data/orders';
import { CreditCard, Wallet } from 'lucide-react';

export default function CheckoutPage() {
  const navigate = useNavigate();
  const { user, updatePoints } = useAuth();
  const { cart, clearCart } = useCartStore();
  
  const [paymentMethod, setPaymentMethod] = useState<string>('credit_card');
  const [usePoints, setUsePoints] = useState(false);
  const [pointsToUse, setPointsToUse] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Calculate available points value (100 points = RM1)
  const maxPointsValue = user ? Math.min(user.points, cart.subtotal * 100) : 0;
  const maxPointsToUse = Math.floor(maxPointsValue / 100) * 100; // Round down to nearest 100
  
  const handlePointsChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value) || 0;
    const capped = Math.min(value, maxPointsToUse);
    setPointsToUse(capped);
    
    if (usePoints) {
      // Apply points to cart (100 points = RM1)
      const discountValue = capped / 100;
      useCartStore.getState().applyPoints(capped);
    }
  };
  
  const toggleUsePoints = () => {
    const newState = !usePoints;
    setUsePoints(newState);
    
    if (newState) {
      // Apply points
      const points = pointsToUse > 0 ? pointsToUse : maxPointsToUse;
      setPointsToUse(points);
      useCartStore.getState().applyPoints(points);
    } else {
      // Remove points discount
      useCartStore.getState().applyPoints(0);
    }
  };
  
  const handleSubmitOrder = async () => {
    if (!user) {
      navigate('/login');
      return;
    }
    
    if (!cart.outlet) {
      alert('Please select an outlet');
      return;
    }
    
    if (cart.orderType === 'dine-in' && !cart.tableNumber) {
      alert('Please enter a table number');
      return;
    }
    
    if (cart.orderType === 'delivery' && !cart.deliveryAddress) {
      alert('Please add a delivery address');
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      // Create new order
      const newOrder = createOrder({
        userId: user.id,
        items: cart.items,
        outlet: cart.outlet,
        orderType: cart.orderType,
        tableNumber: cart.tableNumber,
        deliveryAddress: cart.deliveryAddress,
        status: 'preparing',
        totalAmount: cart.total,
        pointsEarned: Math.floor(cart.total), // 1 point per RM1
        pointsUsed: usePoints ? pointsToUse : 0,
        paymentMethod: paymentMethod === 'credit_card' ? 'Credit Card' : 'E-Wallet',
      });
      
      // Update user points
      const pointsEarned = Math.floor(cart.total);
      const pointsUsed = usePoints ? pointsToUse : 0;
      updatePoints(pointsEarned - pointsUsed);
      
      // Clear cart
      clearCart();
      
      // Navigate to success page
      navigate(`/order-success/${newOrder.id}`);
    } catch (error) {
      console.error('Error creating order:', error);
      alert('There was an error processing your order. Please try again.');
      setIsSubmitting(false);
    }
  };
  
  return (
    <div className="min-h-screen bg-neutral-50 pb-20">
      <TopBar title="Checkout" />
      
      <div className="pt-14 px-4">
        {/* Order Summary */}
        <div className="my-4">
          <h2 className="font-semibold text-lg mb-2">Order Summary</h2>
          <Card>
            <CardContent className="p-3">
              <div className="space-y-2">
                <div className="flex justify-between pb-2 border-b border-neutral-100">
                  <span className="text-neutral-600">Items:</span>
                  <span>{cart.items.length}</span>
                </div>
                <div className="flex justify-between pb-2 border-b border-neutral-100">
                  <span className="text-neutral-600">Order Type:</span>
                  <span className="capitalize">{cart.orderType}</span>
                </div>
                {cart.orderType === 'dine-in' && cart.tableNumber && (
                  <div className="flex justify-between pb-2 border-b border-neutral-100">
                    <span className="text-neutral-600">Table Number:</span>
                    <span>{cart.tableNumber}</span>
                  </div>
                )}
                <div className="flex justify-between pb-2 border-b border-neutral-100">
                  <span className="text-neutral-600">Outlet:</span>
                  <span>{cart.outlet?.name}</span>
                </div>
                <div className="flex justify-between pb-2 border-b border-neutral-100">
                  <span className="text-neutral-600">Subtotal:</span>
                  <span>RM {cart.subtotal.toFixed(2)}</span>
                </div>
                {cart.discount > 0 && (
                  <div className="flex justify-between pb-2 border-b border-neutral-100 text-success-500">
                    <span>Points Discount:</span>
                    <span>-RM {cart.discount.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between font-bold text-lg pt-2">
                  <span>Total:</span>
                  <span>RM {cart.total.toFixed(2)}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* Points */}
        {user && user.points > 0 && (
          <div className="my-4">
            <h2 className="font-semibold text-lg mb-2">Reward Points</h2>
            <Card>
              <CardContent className="p-3">
                <div className="flex justify-between items-center mb-3">
                  <div>
                    <p className="font-semibold">Available Points:</p>
                    <p className="text-sm text-neutral-600">{user.points} points (RM {(user.points / 100).toFixed(2)} value)</p>
                  </div>
                  <div className="flex items-center">
                    <input
                      type="checkbox"
                      id="usePoints"
                      checked={usePoints}
                      onChange={toggleUsePoints}
                      className="w-4 h-4 text-primary-600 rounded focus:ring-primary-500"
                    />
                    <label htmlFor="usePoints" className="ml-2 text-sm">Use Points</label>
                  </div>
                </div>
                
                {usePoints && (
                  <div>
                    <Input
                      type="number"
                      value={pointsToUse}
                      onChange={handlePointsChange}
                      min={0}
                      max={maxPointsToUse}
                      step={100}
                      disabled={!usePoints}
                    />
                    <p className="text-xs text-neutral-500 mt-1">
                      100 points = RM1 discount. You can use up to {maxPointsToUse} points.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        )}
        
        {/* Payment Method */}
        <div className="my-4">
          <h2 className="font-semibold text-lg mb-2">Payment Method</h2>
          <div className="grid grid-cols-2 gap-3">
            <button
              className={`p-4 rounded-lg border flex flex-col items-center ${
                paymentMethod === 'credit_card'
                  ? 'border-primary-500 bg-primary-50'
                  : 'border-neutral-300'
              }`}
              onClick={() => setPaymentMethod('credit_card')}
            >
              <CreditCard className={`w-8 h-8 mb-2 ${
                paymentMethod === 'credit_card' ? 'text-primary-600' : 'text-neutral-500'
              }`} />
              <span className={paymentMethod === 'credit_card' ? 'text-primary-600 font-semibold' : ''}>
                Credit Card
              </span>
            </button>
            <button
              className={`p-4 rounded-lg border flex flex-col items-center ${
                paymentMethod === 'e_wallet'
                  ? 'border-primary-500 bg-primary-50'
                  : 'border-neutral-300'
              }`}
              onClick={() => setPaymentMethod('e_wallet')}
            >
              <Wallet className={`w-8 h-8 mb-2 ${
                paymentMethod === 'e_wallet' ? 'text-primary-600' : 'text-neutral-500'
              }`} />
              <span className={paymentMethod === 'e_wallet' ? 'text-primary-600 font-semibold' : ''}>
                E-Wallet
              </span>
            </button>
          </div>
        </div>
        
        {/* Submit Button */}
        <div className="mt-8">
          <Button
            fullWidth
            size="lg"
            isLoading={isSubmitting}
            onClick={handleSubmitOrder}
          >
            {`Pay RM ${cart.total.toFixed(2)}`}
          </Button>
          <p className="text-center text-xs text-neutral-500 mt-2">
            You will earn {Math.floor(cart.total)} points from this order
          </p>
        </div>
      </div>
    </div>
  );
}