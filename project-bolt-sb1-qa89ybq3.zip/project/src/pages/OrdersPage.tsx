import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { TopBar, Navbar } from '../components/layout/Navbar';
import { Card, CardContent } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { useAuth } from '../context/AuthContext';
import { getUserOrders } from '../data/orders';
import { Order } from '../types';
import { ChevronRight } from 'lucide-react';

export default function OrdersPage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [activeTab, setActiveTab] = useState<'current' | 'history'>('current');
  
  useEffect(() => {
    if (user) {
      setOrders(getUserOrders(user.id));
    }
  }, [user]);
  
  const currentOrders = orders.filter(order => order.status !== 'completed');
  const orderHistory = orders.filter(order => order.status === 'completed');
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString('en-MY', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };
  
  if (!user) {
    return (
      <div className="min-h-screen bg-neutral-50 pb-20">
        <TopBar title="My Orders" />
        
        <div className="pt-14 px-4 flex flex-col items-center justify-center h-[80vh]">
          <p className="text-neutral-500 mb-4">Please log in to view your orders</p>
          <Button onClick={() => navigate('/login')}>Log In</Button>
        </div>
        
        <Navbar />
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-neutral-50 pb-20">
      <TopBar title="My Orders" />
      
      <div className="pt-14 px-4">
        {/* Tabs */}
        <div className="flex border-b border-neutral-200 mb-4">
          <button
            className={`flex-1 py-3 font-medium text-center ${
              activeTab === 'current'
                ? 'text-primary-600 border-b-2 border-primary-600'
                : 'text-neutral-500'
            }`}
            onClick={() => setActiveTab('current')}
          >
            Ongoing Orders
          </button>
          <button
            className={`flex-1 py-3 font-medium text-center ${
              activeTab === 'history'
                ? 'text-primary-600 border-b-2 border-primary-600'
                : 'text-neutral-500'
            }`}
            onClick={() => setActiveTab('history')}
          >
            Order History
          </button>
        </div>
        
        {/* Orders List */}
        <div className="space-y-4">
          {activeTab === 'current' ? (
            currentOrders.length > 0 ? (
              currentOrders.map((order) => (
                <OrderCard key={order.id} order={order} onClick={() => navigate(`/order/${order.id}`)} />
              ))
            ) : (
              <div className="text-center py-8">
                <p className="text-neutral-500 mb-4">You don't have any ongoing orders</p>
                <Button onClick={() => navigate('/menu')}>Order Now</Button>
              </div>
            )
          ) : (
            orderHistory.length > 0 ? (
              orderHistory.map((order) => (
                <OrderCard key={order.id} order={order} onClick={() => navigate(`/order/${order.id}`)} />
              ))
            ) : (
              <div className="text-center py-8">
                <p className="text-neutral-500 mb-4">You don't have any order history</p>
                <Button onClick={() => navigate('/menu')}>Order Now</Button>
              </div>
            )
          )}
        </div>
      </div>
      
      <Navbar />
    </div>
  );
}

function OrderCard({ order, onClick }: { order: Order; onClick: () => void }) {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString('en-MY', {
      day: 'numeric',
      month: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };
  
  const getStatusBadge = (status: Order['status']) => {
    switch (status) {
      case 'preparing':
        return <span className="bg-warning-100 text-warning-600 text-xs py-1 px-2 rounded-full">Preparing</span>;
      case 'ready':
        return <span className="bg-secondary-100 text-secondary-600 text-xs py-1 px-2 rounded-full">Ready</span>;
      case 'delivering':
        return <span className="bg-secondary-100 text-secondary-600 text-xs py-1 px-2 rounded-full">On the way</span>;
      case 'completed':
        return <span className="bg-success-100 text-success-600 text-xs py-1 px-2 rounded-full">Completed</span>;
      default:
        return null;
    }
  };
  
  return (
    <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={onClick}>
      <CardContent className="p-4">
        <div className="flex justify-between items-start mb-2">
          <div>
            <p className="font-semibold">{order.id}</p>
            <p className="text-xs text-neutral-500">{formatDate(order.createdAt)}</p>
          </div>
          {getStatusBadge(order.status)}
        </div>
        
        <div className="flex justify-between items-center mb-3">
          <div>
            <p className="text-sm font-medium">{order.outlet.name}</p>
            <p className="text-xs text-neutral-500 capitalize">{order.orderType}</p>
          </div>
          <p className="font-semibold">RM {order.totalAmount.toFixed(2)}</p>
        </div>
        
        <div className="border-t border-neutral-200 pt-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <img
                src={order.items[0].image}
                alt={order.items[0].name}
                className="w-10 h-10 object-cover rounded-md mr-3"
              />
              <div>
                <p className="font-medium text-sm">{order.items[0].name}</p>
                {order.items.length > 1 && (
                  <p className="text-xs text-neutral-500">
                    +{order.items.length - 1} more item{order.items.length > 2 ? 's' : ''}
                  </p>
                )}
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-neutral-400" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}