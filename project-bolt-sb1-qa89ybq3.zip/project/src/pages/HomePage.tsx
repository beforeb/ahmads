import { useEffect, useState } from 'react';
import { TopBar, Navbar } from '../components/layout/Navbar';
import { PromotionSlider } from '../components/home/PromotionSlider';
import { ActionButtons } from '../components/home/ActionButtons';
import { RecommendedItems } from '../components/home/RecommendedItems';
import { useAuth } from '../context/AuthContext';
import { promotions } from '../data/rewards';
import { getPopularItems, getNewItems } from '../data/menu';
import { MenuItem } from '../types';

export default function HomePage() {
  const { user, checkIn } = useAuth();
  const [popularItems, setPopularItems] = useState<MenuItem[]>([]);
  const [newItems, setNewItems] = useState<MenuItem[]>([]);
  
  useEffect(() => {
    // Get featured items
    setPopularItems(getPopularItems().slice(0, 2));
    setNewItems(getNewItems().slice(0, 2));
    
    // Check in user for daily points
    if (user) {
      checkIn();
    }
  }, [user, checkIn]);
  
  return (
    <div className="min-h-screen bg-neutral-50 pb-20">
      <TopBar />
      
      <div className="pt-14 px-4">
        {/* Greeting */}
        <div className="py-4">
          <h1 className="text-2xl font-bold">
            {user ? `Welcome back, ${user.name.split(' ')[0]}!` : 'Welcome to Ahmads+'}
          </h1>
          <p className="text-neutral-500">What delicious meal are you craving today?</p>
        </div>
        
        {/* Promotions */}
        <PromotionSlider promotions={promotions} />
        
        {/* Main Action Buttons */}
        <div className="my-6">
          <ActionButtons />
        </div>
        
        {/* Popular Items */}
        <RecommendedItems 
          title="Popular Items" 
          items={popularItems} 
          link="/menu"
        />
        
        {/* New Items */}
        <RecommendedItems 
          title="New Arrivals" 
          items={newItems} 
          link="/menu"
        />
        
        {/* Personalized Section */}
        {user && (
          <div className="bg-neutral-100 p-4 rounded-lg shadow-sm mb-8">
            <h2 className="text-lg font-bold mb-3">Just For You</h2>
            <p className="text-neutral-600 text-sm mb-2">
              Based on your previous orders, we think you'll love these:
            </p>
            <div className="grid grid-cols-2 gap-4">
              {popularItems.map((item) => (
                <MenuItem key={item.id} item={item} />
              ))}
            </div>
          </div>
        )}
      </div>
      
      <Navbar />
    </div>
  );
}