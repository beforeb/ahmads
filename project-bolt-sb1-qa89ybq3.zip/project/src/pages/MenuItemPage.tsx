import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { MenuItem, MenuItemOption } from '../types';
import { menuItems, getSimilarItems } from '../data/menu';
import { useCartStore } from '../store/cartStore';
import { TopBar, Navbar } from '../components/layout/Navbar';
import { Button } from '../components/ui/Button';
import { Card, CardContent } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { ChevronLeft, Plus, Minus, ShoppingCart } from 'lucide-react';
import { RecommendedItems } from '../components/home/RecommendedItems';

export default function MenuItemPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const addItem = useCartStore((state) => state.addItem);
  
  const [item, setItem] = useState<MenuItem | null>(null);
  const [quantity, setQuantity] = useState(1);
  const [selectedOptions, setSelectedOptions] = useState<Record<string, string>>({});
  const [similarItems, setSimilarItems] = useState<MenuItem[]>([]);
  const [totalPrice, setTotalPrice] = useState(0);
  
  useEffect(() => {
    if (id) {
      const menuItem = menuItems.find((item) => item.id === id);
      if (menuItem) {
        setItem(menuItem);
        setSimilarItems(getSimilarItems(menuItem.category, menuItem.id));
        
        // Initialize selected options
        const initialOptions: Record<string, string> = {};
        menuItem.options?.forEach((option) => {
          initialOptions[option.id] = option.choices[0].id;
        });
        setSelectedOptions(initialOptions);
        
        // Calculate initial price
        const basePrice = menuItem.discountPrice || menuItem.price;
        setTotalPrice(basePrice);
      } else {
        navigate('/menu');
      }
    }
  }, [id, navigate]);
  
  useEffect(() => {
    if (item) {
      let price = item.discountPrice || item.price;
      
      // Add option prices
      item.options?.forEach((option) => {
        const selectedChoiceId = selectedOptions[option.id];
        if (selectedChoiceId) {
          const choice = option.choices.find((c) => c.id === selectedChoiceId);
          if (choice) {
            price += choice.price;
          }
        }
      });
      
      setTotalPrice(price * quantity);
    }
  }, [item, selectedOptions, quantity]);
  
  const handleOptionChange = (optionId: string, choiceId: string) => {
    setSelectedOptions((prev) => ({
      ...prev,
      [optionId]: choiceId,
    }));
  };
  
  const handleAddToCart = () => {
    if (item) {
      const cartItemOptions = item.options?.map((option) => {
        const choiceId = selectedOptions[option.id];
        const choice = option.choices.find((c) => c.id === choiceId);
        return {
          optionId: option.id,
          choiceId,
          name: option.name,
          choiceName: choice?.name || '',
          price: choice?.price || 0,
        };
      }) || [];
      
      addItem(item, quantity, cartItemOptions);
      navigate('/cart');
    }
  };
  
  if (!item) {
    return <div className="flex justify-center items-center h-screen">Loading...</div>;
  }
  
  return (
    <div className="min-h-screen bg-neutral-50 pb-20">
      <TopBar />
      
      <div className="pt-14">
        {/* Item Image */}
        <div className="relative h-64">
          <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
          <button 
            className="absolute top-4 left-4 bg-white/80 rounded-full p-2"
            onClick={() => navigate(-1)}
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <div className="absolute bottom-4 left-4 flex gap-2">
            {item.isNew && <Badge variant="error">New</Badge>}
            {item.isPopular && <Badge variant="primary">Popular</Badge>}
          </div>
        </div>
        
        {/* Item Details */}
        <div className="px-4 py-4">
          <div className="flex justify-between items-start mb-2">
            <h1 className="text-2xl font-bold">{item.name}</h1>
            <div className="flex flex-col items-end">
              {item.discountPrice ? (
                <>
                  <span className="text-primary-600 font-bold text-xl">
                    RM {item.discountPrice.toFixed(2)}
                  </span>
                  <span className="text-neutral-400 text-sm line-through">
                    RM {item.price.toFixed(2)}
                  </span>
                </>
              ) : (
                <span className="text-primary-600 font-bold text-xl">
                  RM {item.price.toFixed(2)}
                </span>
              )}
            </div>
          </div>
          
          <p className="text-neutral-600 mb-6">{item.description}</p>
          
          {/* Options */}
          {item.options && item.options.map((option: MenuItemOption) => (
            <div key={option.id} className="mb-6">
              <h3 className="font-semibold mb-2">{option.name}</h3>
              <div className="flex flex-wrap gap-2">
                {option.choices.map((choice) => (
                  <button
                    key={choice.id}
                    className={`py-2 px-3 rounded-lg text-sm ${
                      selectedOptions[option.id] === choice.id
                        ? 'bg-primary-100 border border-primary-500 text-primary-700'
                        : 'bg-white border border-neutral-300 text-neutral-700'
                    }`}
                    onClick={() => handleOptionChange(option.id, choice.id)}
                  >
                    {choice.name}
                    {choice.price > 0 && ` (+RM ${choice.price.toFixed(2)})`}
                  </button>
                ))}
              </div>
            </div>
          ))}
          
          {/* Quantity */}
          <div className="flex items-center justify-between mb-6">
            <span className="font-semibold">Quantity</span>
            <div className="flex items-center">
              <button
                className="bg-neutral-100 rounded-full w-8 h-8 flex items-center justify-center"
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
              >
                <Minus className="w-4 h-4" />
              </button>
              <span className="mx-4 font-semibold">{quantity}</span>
              <button
                className="bg-neutral-100 rounded-full w-8 h-8 flex items-center justify-center"
                onClick={() => setQuantity(quantity + 1)}
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>
          </div>
          
          {/* Similar Items */}
          {similarItems.length > 0 && (
            <RecommendedItems title="You May Also Like" items={similarItems} />
          )}
        </div>
      </div>
      
      {/* Add to Cart Button */}
      <div className="fixed bottom-16 left-0 right-0 bg-white border-t border-neutral-200 p-4">
        <div className="flex justify-between items-center mb-2">
          <span className="font-semibold">Total:</span>
          <span className="text-primary-600 font-bold text-xl">RM {totalPrice.toFixed(2)}</span>
        </div>
        <Button
          fullWidth
          size="lg"
          leftIcon={<ShoppingCart className="w-5 h-5" />}
          onClick={handleAddToCart}
        >
          Add to Cart
        </Button>
      </div>
      
      <Navbar />
    </div>
  );
}