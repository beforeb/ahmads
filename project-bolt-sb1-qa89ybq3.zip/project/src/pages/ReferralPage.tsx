import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { TopBar, Navbar } from '../components/layout/Navbar';
import { Card, CardContent } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { useAuth } from '../context/AuthContext';
import { Share, Copy, CheckCircle, Award } from 'lucide-react';

export default function ReferralPage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [copied, setCopied] = useState(false);
  
  const referralLink = user ? `https://ahmadsplus.my/refer/${user.referralCode}` : '';
  
  const handleCopyLink = () => {
    navigator.clipboard.writeText(referralLink);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  
  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: 'Join Ahmads+ Fast Food App',
        text: 'Use my referral code to get a discount on your first order!',
        url: referralLink,
      });
    } else {
      handleCopyLink();
    }
  };
  
  if (!user) {
    return (
      <div className="min-h-screen bg-neutral-50 pb-20">
        <TopBar title="My Referral" />
        
        <div className="pt-14 px-4 flex flex-col items-center justify-center h-[80vh]">
          <p className="text-neutral-500 mb-4">Please log in to access your referral code</p>
          <Button onClick={() => navigate('/login')}>Log In</Button>
        </div>
        
        <Navbar />
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-neutral-50 pb-20">
      <TopBar title="My Referral" />
      
      <div className="pt-14 px-4">
        {/* Referral Banner */}
        <div className="bg-primary-600 text-white rounded-lg p-6 my-4 text-center">
          <Award className="w-12 h-12 mx-auto mb-3" />
          <h2 className="text-xl font-bold mb-2">Invite Friends, Earn Rewards</h2>
          <p className="text-sm opacity-90 mb-4">
            When your friend makes their first order, you'll earn 500 points (RM5)!
          </p>
        </div>
        
        {/* Referral Code */}
        <Card className="mb-6">
          <CardContent className="p-4">
            <h3 className="font-semibold mb-2">Your Referral Code</h3>
            <div className="bg-neutral-100 p-3 rounded-lg flex justify-between items-center mb-4">
              <span className="font-bold tracking-wider text-lg">{user.referralCode}</span>
              <button
                className="bg-primary-600 text-white p-2 rounded-full"
                onClick={handleCopyLink}
              >
                {copied ? <CheckCircle className="w-5 h-5" /> : <Copy className="w-5 h-5" />}
              </button>
            </div>
            
            <Button
              fullWidth
              leftIcon={<Share className="w-5 h-5" />}
              onClick={handleShare}
            >
              Share Your Referral Link
            </Button>
          </CardContent>
        </Card>
        
        {/* How It Works */}
        <Card>
          <CardContent className="p-4">
            <h3 className="font-semibold mb-3">How It Works</h3>
            
            <div className="space-y-4">
              <div className="flex">
                <div className="w-8 h-8 rounded-full bg-primary-100 text-primary-600 flex items-center justify-center mr-3 flex-shrink-0">
                  1
                </div>
                <div>
                  <p className="font-medium">Share your referral code</p>
                  <p className="text-sm text-neutral-500">
                    Send your unique code to friends and family
                  </p>
                </div>
              </div>
              
              <div className="flex">
                <div className="w-8 h-8 rounded-full bg-primary-100 text-primary-600 flex items-center justify-center mr-3 flex-shrink-0">
                  2
                </div>
                <div>
                  <p className="font-medium">Friend signs up & orders</p>
                  <p className="text-sm text-neutral-500">
                    They enter your code during registration
                  </p>
                </div>
              </div>
              
              <div className="flex">
                <div className="w-8 h-8 rounded-full bg-primary-100 text-primary-600 flex items-center justify-center mr-3 flex-shrink-0">
                  3
                </div>
                <div>
                  <p className="font-medium">You both get rewarded</p>
                  <p className="text-sm text-neutral-500">
                    You receive 500 points (RM5) after their first order
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <Navbar />
    </div>
  );
}