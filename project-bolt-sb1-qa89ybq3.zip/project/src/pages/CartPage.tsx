import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { TopBar, Navbar } from '../components/layout/Navbar';
import { Button } from '../components/ui/Button';
import { Card, CardContent } from '../components/ui/Card';
import { Input } from '../components/ui/Input';
import { useCartStore } from '../store/cartStore';
import { useAuth } from '../context/AuthContext';
import { Plus, Minus, Trash2, MapPin, ChevronRight } from 'lucide-react';
import { outlets } from '../data/outlets';
import { Outlet } from '../types';

export default function CartPage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { cart, removeItem, updateQuantity, setOrderType, setTableNumber, setOutlet } = useCartStore();
  
  const [selectedOutlet, setSelectedOutlet] = useState<Outlet | null>(null);
  const [tableNum, setTableNum] = useState('');
  
  useEffect(() => {
    // Set default outlet
    if (!cart.outlet && outlets.length > 0) {
      const defaultOutlet = outlets[0];
      setSelectedOutlet(defaultOutlet);
      setOutlet(defaultOutlet);
    } else if (cart.outlet) {
      setSelectedOutlet(cart.outlet);
    }
    
    // Set table number from cart if available
    if (cart.tableNumber) {
      setTableNum(cart.tableNumber);
    }
  }, [cart.outlet, cart.tableNumber, setOutlet]);
  
  const handleRemoveItem = (id: string) => {
    removeItem(id);
  };
  
  const handleQuantityChange = (id: string, quantity: number) => {
    updateQuantity(id, quantity);
  };
  
  const handleOrderTypeChange = (type: 'dine-in' | 'delivery') => {
    setOrderType(type);
  };
  
  const handleTableNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setTableNum(e.target.value);
  };
  
  const handleTableNumberBlur = () => {
    setTableNumber(tableNum);
  };
  
  const handleCheckout = () => {
    if (cart.items.length === 0) {
      alert('Your cart is empty');
      return;
    }
    
    if (cart.orderType === 'dine-in' && !cart.tableNumber) {
      alert('Please enter a table number');
      return;
    }
    
    if (!cart.outlet) {
      alert('Please select an outlet');
      return;
    }
    
    navigate('/checkout');
  };
  
  return (
    <div className="min-h-screen bg-neutral-50 pb-32">
      <TopBar title="Your Cart" />
      
      <div className="pt-14 px-4">
        {/* Order Type */}
        <div className="my-4">
          <h2 className="font-semibold mb-2">Order Type:</h2>
          <div className="flex gap-2">
            <button
              className={`flex-1 py-2 px-4 rounded-lg ${
                cart.orderType === 'dine-in'
                  ? 'bg-primary-600 text-white'
                  : 'bg-white border border-neutral-300 text-neutral-700'
              }`}
              onClick={() => handleOrderTypeChange('dine-in')}
            >
              Dine In
            </button>
            <button
              className={`flex-1 py-2 px-4 rounded-lg ${
                cart.orderType === 'delivery'
                  ? 'bg-primary-600 text-white'
                  : 'bg-white border border-neutral-300 text-neutral-700'
              }`}
              onClick={() => handleOrderTypeChange('delivery')}
            >
              Delivery
            </button>
          </div>
        </div>
        
        {/* Outlet Selection */}
        <Card className="mb-4">
          <CardContent className="p-3">
            <div className="flex justify-between items-center">
              <div className="flex items-center">
                <MapPin className="w-5 h-5 text-primary-600 mr-2" />
                <div>
                  <p className="font-semibold">Outlet:</p>
                  <p className="text-sm text-neutral-600">
                    {selectedOutlet?.name || 'Select an outlet'}
                  </p>
                </div>
              </div>
              <button 
                className="text-primary-600"
                onClick={() => navigate('/outlets')}
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </CardContent>
        </Card>
        
        {/* Table Number (for dine-in) */}
        {cart.orderType === 'dine-in' && (
          <div className="mb-4">
            <Input
              label="Table Number:"
              placeholder="Enter your table number"
              value={tableNum}
              onChange={handleTableNumberChange}
              onBlur={handleTableNumberBlur}
            />
          </div>
        )}
        
        {/* Delivery Address (for delivery) */}
        {cart.orderType === 'delivery' && (
          <Card className="mb-4">
            <CardContent className="p-3">
              <div className="flex justify-between items-center">
                <div>
                  <p className="font-semibold">Delivery Address:</p>
                  <p className="text-sm text-neutral-600">
                    {cart.deliveryAddress?.fullAddress || 'Add an address'}
                  </p>
                </div>
                <button 
                  className="text-primary-600"
                  onClick={() => navigate('/address')}
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>
            </CardContent>
          </Card>
        )}
        
        {/* Cart Items */}
        <h2 className="font-semibold mb-2">Items ({cart.items.length}):</h2>
        {cart.items.length === 0 ? (
          <div className="bg-white rounded-lg p-8 text-center">
            <p className="text-neutral-500 mb-4">Your cart is empty</p>
            <Button onClick={() => navigate('/menu')}>Browse Menu</Button>
          </div>
        ) : (
          <div className="space-y-4 mb-6">
            {cart.items.map((item) => (
              <Card key={item.id}>
                <CardContent className="p-3">
                  <div className="flex">
                    <img 
                      src={item.image} 
                      alt={item.name} 
                      className="w-20 h-20 object-cover rounded-lg mr-3"
                    />
                    <div className="flex-1">
                      <div className="flex justify-between">
                        <h3 className="font-semibold">{item.name}</h3>
                        <button 
                          className="text-neutral-400 hover:text-error-500"
                          onClick={() => handleRemoveItem(item.id)}
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                      </div>
                      
                      {item.selectedOptions.length > 0 && (
                        <div className="mt-1 mb-2">
                          {item.selectedOptions.map((option) => (
                            <p key={option.optionId} className="text-xs text-neutral-500">
                              {option.name}: {option.choiceName}
                              {option.price > 0 && ` (+RM ${option.price.toFixed(2)})`}
                            </p>
                          ))}
                        </div>
                      )}
                      
                      <div className="flex justify-between items-center mt-2">
                        <div className="flex items-center">
                          <button
                            className="bg-neutral-100 rounded-full w-6 h-6 flex items-center justify-center"
                            onClick={() => handleQuantityChange(item.id, Math.max(1, item.quantity - 1))}
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="mx-2 text-sm font-semibold">{item.quantity}</span>
                          <button
                            className="bg-neutral-100 rounded-full w-6 h-6 flex items-center justify-center"
                            onClick={() => handleQuantityChange(item.id, item.quantity + 1)}
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                        <p className="font-semibold text-primary-600">
                          RM {(
                            (item.price + 
                              item.selectedOptions.reduce((sum, opt) => sum + opt.price, 0)
                            ) * item.quantity
                          ).toFixed(2)}
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
      
      {/* Checkout Summary */}
      <div className="fixed bottom-16 left-0 right-0 bg-white border-t border-neutral-200 p-4">
        <div className="space-y-2 mb-4">
          <div className="flex justify-between">
            <span>Subtotal:</span>
            <span>RM {cart.subtotal.toFixed(2)}</span>
          </div>
          {cart.discount > 0 && (
            <div className="flex justify-between text-success-500">
              <span>Points Applied:</span>
              <span>-RM {cart.discount.toFixed(2)}</span>
            </div>
          )}
          <div className="flex justify-between font-bold text-lg pt-2 border-t border-neutral-200">
            <span>Total:</span>
            <span>RM {cart.total.toFixed(2)}</span>
          </div>
        </div>
        
        <Button
          fullWidth
          size="lg"
          disabled={cart.items.length === 0}
          onClick={handleCheckout}
        >
          Proceed to Checkout
        </Button>
      </div>
      
      <Navbar />
    </div>
  );
}