import { useState } from 'react';
import { TopBar, Navbar } from '../components/layout/Navbar';
import { Input } from '../components/ui/Input';
import { Search } from 'lucide-react';
import { MenuCategoryTab, MenuCategoryList } from '../components/menu/MenuCategory';
import { categories, searchMenu } from '../data/menu';
import { MenuItem } from '../components/menu/MenuItem';
import { MenuItem as MenuItemType } from '../types';

export default function MenuPage() {
  const [activeCategory, setActiveCategory] = useState(categories[0].id);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<MenuItemType[]>([]);
  
  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const query = e.target.value;
    setSearchQuery(query);
    
    if (query.trim().length > 2) {
      setSearchResults(searchMenu(query));
    } else {
      setSearchResults([]);
    }
  };
  
  return (
    <div className="min-h-screen bg-neutral-50 pb-20">
      <TopBar title="Menu" />
      
      <div className="pt-14 px-4">
        {/* Search */}
        <div className="my-4">
          <Input
            placeholder="Search for food items..."
            value={searchQuery}
            onChange={handleSearch}
            leftIcon={<Search className="w-5 h-5 text-neutral-400" />}
          />
        </div>
        
        {searchQuery.trim().length > 2 ? (
          <div>
            <h2 className="text-lg font-semibold mb-3">Search Results</h2>
            {searchResults.length > 0 ? (
              <div className="grid grid-cols-2 gap-4">
                {searchResults.map((item) => (
                  <MenuItem key={item.id} item={item} />
                ))}
              </div>
            ) : (
              <p className="text-center text-neutral-500 my-8">No items found matching "{searchQuery}"</p>
            )}
          </div>
        ) : (
          <>
            {/* Categories */}
            <div className="grid grid-cols-4 gap-2 mb-6">
              {categories.map((category) => (
                <MenuCategoryTab
                  key={category.id}
                  category={category}
                  activeCategory={activeCategory}
                  setActiveCategory={setActiveCategory}
                />
              ))}
            </div>
            
            {/* Menu Items */}
            <MenuCategoryList categoryId={activeCategory} />
          </>
        )}
      </div>
      
      <Navbar />
    </div>
  );
}