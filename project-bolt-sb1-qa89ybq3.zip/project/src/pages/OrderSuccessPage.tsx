import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { TopBar } from '../components/layout/Navbar';
import { Button } from '../components/ui/Button';
import { Card, CardContent } from '../components/ui/Card';
import { CheckCircle, ChevronRight, Clock } from 'lucide-react';
import { getOrderById } from '../data/orders';
import { Order } from '../types';

export default function OrderSuccessPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [order, setOrder] = useState<Order | null>(null);
  
  useEffect(() => {
    if (id) {
      const orderData = getOrderById(id);
      if (orderData) {
        setOrder(orderData);
      } else {
        navigate('/orders');
      }
    }
  }, [id, navigate]);
  
  if (!order) {
    return <div className="flex justify-center items-center h-screen">Loading...</div>;
  }
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString('en-MY', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };
  
  return (
    <div className="min-h-screen bg-neutral-50">
      <TopBar title="Order Confirmation" />
      
      <div className="pt-14 px-4 pb-20">
        {/* Success Message */}
        <div className="flex flex-col items-center justify-center py-8">
          <div className="bg-success-500 rounded-full p-3 mb-4">
            <CheckCircle className="w-12 h-12 text-white" />
          </div>
          <h1 className="text-2xl font-bold mb-2">Order Confirmed!</h1>
          <p className="text-neutral-600 text-center mb-6">
            Your order has been placed successfully and is being prepared.
          </p>
          
          {/* Order ID */}
          <Card className="w-full mb-6">
            <CardContent className="p-4">
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-sm text-neutral-500">Order ID</p>
                  <p className="font-semibold">{order.id}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-neutral-500">Date</p>
                  <p className="font-semibold">{formatDate(order.createdAt)}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Order Status */}
          <Card className="w-full mb-6">
            <CardContent className="p-4">
              <div className="flex items-center mb-4">
                <Clock className="w-5 h-5 text-primary-600 mr-2" />
                <h3 className="font-semibold">Order Status</h3>
              </div>
              
              <div className="relative">
                <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-neutral-200"></div>
                
                <div className="relative flex mb-6 pl-10">
                  <div className="absolute left-3 w-3 h-3 rounded-full bg-primary-600 -ml-1.5 mt-1"></div>
                  <div>
                    <p className="font-semibold">Order Placed</p>
                    <p className="text-sm text-neutral-500">Your order has been received</p>
                  </div>
                </div>
                
                <div className="relative flex mb-6 pl-10">
                  <div className="absolute left-3 w-3 h-3 rounded-full bg-primary-200 -ml-1.5 mt-1"></div>
                  <div>
                    <p className="font-semibold text-neutral-400">Preparing</p>
                    <p className="text-sm text-neutral-500">Your food is being prepared</p>
                  </div>
                </div>
                
                <div className="relative flex pl-10">
                  <div className="absolute left-3 w-3 h-3 rounded-full bg-neutral-300 -ml-1.5 mt-1"></div>
                  <div>
                    <p className="font-semibold text-neutral-400">
                      {order.orderType === 'delivery' ? 'On the way' : 'Ready for pickup'}
                    </p>
                    <p className="text-sm text-neutral-500">
                      {order.orderType === 'delivery' 
                        ? 'Your order is on its way to you' 
                        : 'Your order is ready for pickup'}
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Order Details */}
          <Card className="w-full mb-6">
            <CardContent className="p-4">
              <h3 className="font-semibold mb-3">Order Details</h3>
              
              <div className="mb-4">
                <p className="text-sm text-neutral-500 mb-1">Outlet</p>
                <p className="font-medium">{order.outlet.name}</p>
              </div>
              
              <div className="mb-4">
                <p className="text-sm text-neutral-500 mb-1">Order Type</p>
                <p className="font-medium capitalize">{order.orderType}</p>
                {order.orderType === 'dine-in' && order.tableNumber && (
                  <p className="text-sm">Table #{order.tableNumber}</p>
                )}
                {order.orderType === 'delivery' && order.deliveryAddress && (
                  <p className="text-sm">{order.deliveryAddress.fullAddress}</p>
                )}
              </div>
              
              <div className="mb-4">
                <p className="text-sm text-neutral-500 mb-1">Payment Method</p>
                <p className="font-medium">{order.paymentMethod}</p>
              </div>
              
              <div className="border-t border-neutral-200 pt-4 mt-4">
                <h4 className="font-semibold mb-2">Items</h4>
                {order.items.map((item) => (
                  <div key={item.id} className="flex justify-between mb-2">
                    <div>
                      <p className="font-medium">{item.quantity}x {item.name}</p>
                      {item.selectedOptions.map((option) => (
                        <p key={option.optionId} className="text-xs text-neutral-500">
                          {option.name}: {option.choiceName}
                        </p>
                      ))}
                    </div>
                    <p className="font-medium">
                      RM {((item.price + item.selectedOptions.reduce((sum, opt) => sum + opt.price, 0)) * item.quantity).toFixed(2)}
                    </p>
                  </div>
                ))}
              </div>
              
              <div className="border-t border-neutral-200 pt-4 mt-4">
                <div className="flex justify-between mb-1">
                  <p className="text-neutral-500">Subtotal</p>
                  <p>RM {order.totalAmount.toFixed(2)}</p>
                </div>
                {order.pointsUsed > 0 && (
                  <div className="flex justify-between mb-1 text-success-500">
                    <p>Points Used</p>
                    <p>-RM {(order.pointsUsed / 100).toFixed(2)}</p>
                  </div>
                )}
                <div className="flex justify-between font-bold mt-2">
                  <p>Total</p>
                  <p>RM {order.totalAmount.toFixed(2)}</p>
                </div>
              </div>
              
              <div className="mt-4 bg-neutral-100 p-3 rounded-lg">
                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-sm font-medium">Points Earned</p>
                    <p className="text-primary-600 font-bold">+{order.pointsEarned} points</p>
                  </div>
                  <ChevronRight className="w-5 h-5 text-neutral-400" />
                </div>
              </div>
            </CardContent>
          </Card>
          
          <div className="w-full space-y-3">
            <Button fullWidth onClick={() => navigate('/orders')}>
              Track Order
            </Button>
            <Button fullWidth variant="outline" onClick={() => navigate('/')}>
              Back to Home
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}