import { Reward, Promotion } from '../types';

export const rewards: Reward[] = [
  {
    id: '1',
    name: 'Free Classic Burger',
    description: 'Redeem for a free Ahmads Classic Burger',
    pointsCost: 500,
    image: 'https://images.pexels.com/photos/1639557/pexels-photo-1639557.jpeg?auto=compress&cs=tinysrgb&w=800',
  },
  {
    id: '2',
    name: 'Free Crispy Chicken',
    description: '2 pieces of our famous crispy fried chicken',
    pointsCost: 400,
    image: 'https://images.pexels.com/photos/60616/fried-chicken-chicken-fried-crunchy-60616.jpeg?auto=compress&cs=tinysrgb&w=800',
  },
  {
    id: '3',
    name: '50% Off Any Combo Meal',
    description: 'Get half price on any combo meal',
    pointsCost: 300,
    image: 'https://images.pexels.com/photos/1199960/pexels-photo-1199960.jpeg?auto=compress&cs=tinysrgb&w=800',
    expiryDate: new Date(2025, 6, 30).toISOString(),
  },
  {
    id: '4',
    name: 'Free Milkshake',
    description: 'Enjoy a free classic milkshake of your choice',
    pointsCost: 200,
    image: 'https://images.pexels.com/photos/103566/pexels-photo-103566.jpeg?auto=compress&cs=tinysrgb&w=800',
  },
];

export const promotions: Promotion[] = [
  {
    id: '1',
    title: 'Burger Bonanza',
    description: 'Enjoy 20% off on all burgers this week!',
    image: 'https://images.pexels.com/photos/2983101/pexels-photo-2983101.jpeg?auto=compress&cs=tinysrgb&w=800',
    discountPercentage: 20,
    validUntil: new Date(2025, 5, 30).toISOString(),
    categoryIds: ['burgers'],
  },
  {
    id: '2',
    title: 'Family Feast',
    description: 'Order any 3 combo meals and get 1 free!',
    image: 'https://images.pexels.com/photos/1449773/pexels-photo-1449773.jpeg?auto=compress&cs=tinysrgb&w=800',
    discountPercentage: 25,
    validUntil: new Date(2025, 5, 15).toISOString(),
    categoryIds: ['combo'],
    minimumSpend: 50,
  },
  {
    id: '3',
    title: 'Happy Hour',
    description: 'All drinks half price between 3PM-5PM daily',
    image: 'https://images.pexels.com/photos/2668498/pexels-photo-2668498.jpeg?auto=compress&cs=tinysrgb&w=800',
    discountPercentage: 50,
    validUntil: new Date(2025, 6, 1).toISOString(),
    categoryIds: ['drinks'],
  },
];

export const getUserRecommendations = (userId: string): Promotion[] => {
  // In a real app, this would use the user's order history to personalize
  // For this demo, we'll just return all promotions
  return promotions;
};