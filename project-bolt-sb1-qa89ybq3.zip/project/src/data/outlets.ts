import { Outlet } from '../types';

export const outlets: Outlet[] = [
  {
    id: '1',
    name: 'Ahmads Bukit Bintang',
    address: 'Lot 123, Jalan Bukit Bintang, 55100 Kuala Lumpur',
    latitude: 3.1470,
    longitude: 101.7132,
    isOpen: true,
    openingHours: '8:00 AM - 11:00 PM',
  },
  {
    id: '2',
    name: 'Ahmads Mid Valley',
    address: 'G-012, Ground Floor, Mid Valley Megamall, 59200 Kuala Lumpur',
    latitude: 3.1175,
    longitude: 101.6773,
    isOpen: true,
    openingHours: '10:00 AM - 10:00 PM',
  },
  {
    id: '3',
    name: 'Ahmads Subang Jaya',
    address: 'No. 5, Jalan SS15/4, 47500 Subang Jaya, Selangor',
    latitude: 3.0753,
    longitude: 101.5850,
    isOpen: true,
    openingHours: '9:00 AM - 10:00 PM',
  },
  {
    id: '4',
    name: 'Ahmads Bangsar',
    address: '10, Jalan Telawi 2, Bangsar Baru, 59100 Kuala Lumpur',
    latitude: 3.1320,
    longitude: 101.6716,
    isOpen: true,
    openingHours: '8:00 AM - 11:00 PM',
  },
  {
    id: '5',
    name: 'Ahmads Putrajaya',
    address: 'Lot G17, IOI City Mall, Lebuh IRC, 62502 Putrajaya',
    latitude: 2.9696,
    longitude: 101.7143,
    isOpen: true,
    openingHours: '10:00 AM - 10:00 PM',
  },
];

export const getNearestOutlets = (latitude: number, longitude: number): Outlet[] => {
  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const R = 6371; // Radius of Earth in kilometers
    const dLat = (lat2 - lat1) * (Math.PI / 180);
    const dLon = (lon2 - lon1) * (Math.PI / 180);
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(lat1 * (Math.PI / 180)) * Math.cos(lat2 * (Math.PI / 180)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };

  return outlets
    .map(outlet => ({
      ...outlet,
      distance: calculateDistance(latitude, longitude, outlet.latitude, outlet.longitude),
    }))
    .sort((a, b) => (a.distance || 0) - (b.distance || 0));
};

export const getOutletById = (id: string): Outlet | undefined => {
  return outlets.find(outlet => outlet.id === id);
};