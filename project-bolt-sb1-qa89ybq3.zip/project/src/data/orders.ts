import { Order } from '../types';
import { getOutletById } from './outlets';

// Mock data for orders
const mockOrders: Order[] = [
  {
    id: 'ORD12345',
    userId: '1',
    items: [
      {
        id: 'ci1',
        menuItemId: 'c1',
        name: 'Crispy Fried Chicken',
        price: 12.90,
        quantity: 2,
        image: 'https://images.pexels.com/photos/60616/fried-chicken-chicken-fried-crunchy-60616.jpeg?auto=compress&cs=tinysrgb&w=800',
        selectedOptions: [
          {
            optionId: 'part',
            choiceId: 'mixed',
            name: 'Chicken Part',
            choiceName: 'Mixed Parts',
            price: 0,
          },
          {
            optionId: 'flavor',
            choiceId: 'original',
            name: 'Flavor',
            choiceName: 'Original',
            price: 0,
          },
        ],
      },
    ],
    outlet: getOutletById('1') || {
      id: '1',
      name: 'Ahmads Bukit Bintang',
      address: 'Lot 123, Jalan Bukit Bintang, 55100 Kuala Lumpur',
      latitude: 3.1470,
      longitude: 101.7132,
      isOpen: true,
      openingHours: '8:00 AM - 11:00 PM',
    },
    orderType: 'dine-in',
    tableNumber: '15',
    status: 'completed',
    totalAmount: 25.80,
    pointsEarned: 26,
    pointsUsed: 0,
    paymentMethod: 'Credit Card',
    createdAt: new Date(2025, 4, 10, 9, 39).toISOString(),
  },
  {
    id: 'ORD12346',
    userId: '1',
    items: [
      {
        id: 'ci2',
        menuItemId: 'c1',
        name: 'Crispy Fried Chicken',
        price: 12.90,
        quantity: 3,
        image: 'https://images.pexels.com/photos/60616/fried-chicken-chicken-fried-crunchy-60616.jpeg?auto=compress&cs=tinysrgb&w=800',
        selectedOptions: [
          {
            optionId: 'part',
            choiceId: 'mixed',
            name: 'Chicken Part',
            choiceName: 'Mixed Parts',
            price: 0,
          },
          {
            optionId: 'flavor',
            choiceId: 'original',
            name: 'Flavor',
            choiceName: 'Original',
            price: 0,
          },
        ],
      },
    ],
    outlet: getOutletById('1') || {
      id: '1',
      name: 'Ahmads Bukit Bintang',
      address: 'Lot 123, Jalan Bukit Bintang, 55100 Kuala Lumpur',
      latitude: 3.1470,
      longitude: 101.7132,
      isOpen: true,
      openingHours: '8:00 AM - 11:00 PM',
    },
    orderType: 'dine-in',
    tableNumber: '15',
    status: 'completed',
    totalAmount: 38.70,
    pointsEarned: 39,
    pointsUsed: 0,
    paymentMethod: 'Credit Card',
    createdAt: new Date(2025, 4, 9, 10, 39).toISOString(),
  },
];

export const getUserOrders = (userId: string): Order[] => {
  return mockOrders
    .filter(order => order.userId === userId)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
};

export const getOrderById = (orderId: string): Order | undefined => {
  return mockOrders.find(order => order.id === orderId);
};

export const createOrder = (order: Omit<Order, 'id' | 'createdAt'>): Order => {
  const newOrder: Order = {
    ...order,
    id: 'ORD' + Math.floor(Math.random() * 100000),
    createdAt: new Date().toISOString(),
  };
  
  mockOrders.push(newOrder);
  
  return newOrder;
};

export const updateOrderStatus = (orderId: string, status: Order['status']): Order | undefined => {
  const orderIndex = mockOrders.findIndex(order => order.id === orderId);
  
  if (orderIndex === -1) return undefined;
  
  mockOrders[orderIndex] = {
    ...mockOrders[orderIndex],
    status,
  };
  
  return mockOrders[orderIndex];
};