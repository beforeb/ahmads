import { MenuItem, MenuCategory } from '../types';

export const categories: MenuCategory[] = [
  {
    id: 'burgers',
    name: 'Burgers',
    icon: 'Beef',
  },
  {
    id: 'chicken',
    name: 'Chicken',
    icon: 'Drumstick',
  },
  {
    id: 'combo',
    name: 'Combo Meals',
    icon: 'UtensilsCrossed',
  },
  {
    id: 'drinks',
    name: 'Drinks',
    icon: 'Coffee',
  },
  {
    id: 'sides',
    name: 'Sides',
    icon: 'Sandwich',
  },
];

export const menuItems: MenuItem[] = [
  {
    id: 'b1',
    name: 'Ahmads Classic Burger',
    description: 'Our signature beef burger with lettuce, tomato, cheese, and secret sauce',
    price: 15.90,
    image: 'https://images.pexels.com/photos/1639557/pexels-photo-1639557.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'burgers',
    isPopular: true,
    options: [
      {
        id: 'patty',
        name: 'Patty Type',
        choices: [
          { id: 'beef', name: 'Beef', price: 0 },
          { id: 'chicken', name: 'Chicken', price: 0 },
          { id: 'vegan', name: 'Plant-based', price: 2 },
        ],
      },
      {
        id: 'size',
        name: 'Size',
        choices: [
          { id: 'regular', name: 'Regular', price: 0 },
          { id: 'double', name: 'Double Patty', price: 5 },
        ],
      },
      {
        id: 'extras',
        name: 'Add Extras',
        choices: [
          { id: 'cheese', name: 'Extra Cheese', price: 2 },
          { id: 'beef', name: 'Beef Bacon', price: 3 },
          { id: 'egg', name: 'Fried Egg', price: 2 },
          { id: 'jalapeno', name: 'Jalapeños', price: 1 },
        ],
      },
    ],
  },
  {
    id: 'b2',
    name: 'Spicy Deluxe Burger',
    description: 'Beef patty with jalapeños, pepper jack cheese, and spicy mayo',
    price: 17.90,
    image: 'https://images.pexels.com/photos/2271107/pexels-photo-2271107.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'burgers',
    isNew: true,
    options: [
      {
        id: 'spice',
        name: 'Spice Level',
        choices: [
          { id: 'mild', name: 'Mild', price: 0 },
          { id: 'medium', name: 'Medium', price: 0 },
          { id: 'hot', name: 'Hot', price: 0 },
          { id: 'extreme', name: 'Extreme', price: 1 },
        ],
      },
      {
        id: 'size',
        name: 'Size',
        choices: [
          { id: 'regular', name: 'Regular', price: 0 },
          { id: 'double', name: 'Double Patty', price: 5 },
        ],
      },
    ],
  },
  {
    id: 'c1',
    name: 'Crispy Fried Chicken',
    description: '2 pieces of our famous crispy fried chicken with secret spices',
    price: 12.90,
    discountPrice: 10.90,
    image: 'https://images.pexels.com/photos/60616/fried-chicken-chicken-fried-crunchy-60616.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'chicken',
    isPopular: true,
    options: [
      {
        id: 'part',
        name: 'Chicken Part',
        choices: [
          { id: 'mixed', name: 'Mixed Parts', price: 0 },
          { id: 'breast', name: 'Breast Only', price: 2 },
          { id: 'thigh', name: 'Thigh Only', price: 2 },
        ],
      },
      {
        id: 'flavor',
        name: 'Flavor',
        choices: [
          { id: 'original', name: 'Original', price: 0 },
          { id: 'spicy', name: 'Spicy', price: 0 },
          { id: 'bbq', name: 'BBQ', price: 0 },
        ],
      },
    ],
  },
  {
    id: 'cm1',
    name: 'Ultimate Beef Meal',
    description: 'Beef burger, fries, and a drink of your choice',
    price: 21.90,
    image: 'https://images.pexels.com/photos/1199960/pexels-photo-1199960.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'combo',
    isPopular: true,
    options: [
      {
        id: 'drink',
        name: 'Choose Drink',
        choices: [
          { id: 'coke', name: 'Coca Cola', price: 0 },
          { id: 'sprite', name: 'Sprite', price: 0 },
          { id: 'fanta', name: 'Fanta', price: 0 },
          { id: 'water', name: 'Mineral Water', price: 0 },
        ],
      },
      {
        id: 'fries',
        name: 'Fries Size',
        choices: [
          { id: 'regular', name: 'Regular', price: 0 },
          { id: 'large', name: 'Large', price: 2 },
        ],
      },
      {
        id: 'upgrade',
        name: 'Upgrade Burger',
        choices: [
          { id: 'none', name: 'No Upgrade', price: 0 },
          { id: 'double', name: 'Double Patty', price: 5 },
          { id: 'cheese', name: 'Extra Cheese', price: 2 },
        ],
      },
    ],
  },
  {
    id: 'd1',
    name: 'Classic Milkshake',
    description: 'Creamy milkshake made with premium ice cream',
    price: 8.90,
    image: 'https://images.pexels.com/photos/103566/pexels-photo-103566.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'drinks',
    options: [
      {
        id: 'flavor',
        name: 'Flavor',
        choices: [
          { id: 'vanilla', name: 'Vanilla', price: 0 },
          { id: 'chocolate', name: 'Chocolate', price: 0 },
          { id: 'strawberry', name: 'Strawberry', price: 0 },
          { id: 'caramel', name: 'Caramel', price: 1 },
        ],
      },
      {
        id: 'topping',
        name: 'Topping',
        choices: [
          { id: 'none', name: 'No Topping', price: 0 },
          { id: 'whipped', name: 'Whipped Cream', price: 1 },
          { id: 'cherry', name: 'Cherry', price: 1 },
          { id: 'sprinkles', name: 'Sprinkles', price: 1 },
        ],
      },
    ],
  },
  {
    id: 's1',
    name: 'Loaded Fries',
    description: 'Crispy fries topped with cheese sauce, beef bacon and jalapeños',
    price: 10.90,
    image: 'https://images.pexels.com/photos/1893556/pexels-photo-1893556.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'sides',
    isNew: true,
    options: [
      {
        id: 'size',
        name: 'Size',
        choices: [
          { id: 'regular', name: 'Regular', price: 0 },
          { id: 'large', name: 'Large', price: 3 },
        ],
      },
      {
        id: 'extras',
        name: 'Extra Toppings',
        choices: [
          { id: 'cheese', name: 'Extra Cheese', price: 2 },
          { id: 'bacon', name: 'Extra Bacon', price: 3 },
          { id: 'jalapeno', name: 'Extra Jalapeños', price: 1 },
        ],
      },
    ],
  },
];

export const getMenuByCategory = (categoryId: string): MenuItem[] => {
  return menuItems.filter(item => item.category === categoryId);
};

export const getPopularItems = (): MenuItem[] => {
  return menuItems.filter(item => item.isPopular);
};

export const getNewItems = (): MenuItem[] => {
  return menuItems.filter(item => item.isNew);
};

export const getSimilarItems = (categoryId: string, currentItemId: string): MenuItem[] => {
  return menuItems.filter(item => item.category === categoryId && item.id !== currentItemId).slice(0, 3);
};

export const searchMenu = (query: string): MenuItem[] => {
  const lowerQuery = query.toLowerCase();
  return menuItems.filter(
    item => 
      item.name.toLowerCase().includes(lowerQuery) || 
      item.description.toLowerCase().includes(lowerQuery)
  );
};