import { Link } from 'react-router-dom';
import { ShoppingBag, Share2 } from 'lucide-react';

export function ActionButtons() {
  return (
    <div className="grid grid-cols-2 gap-4 mb-6">
      <Link 
        to="/menu" 
        className="flex items-center justify-center bg-primary-600 text-white rounded-2xl py-5 shadow-md transition-transform hover:scale-105"
      >
        <div className="flex flex-col items-center">
          <ShoppingBag className="w-8 h-8 mb-1" />
          <span className="text-lg font-bold">ORDER NOW</span>
        </div>
      </Link>
      <Link 
        to="/referral" 
        className="flex items-center justify-center bg-secondary-100 text-secondary-700 rounded-2xl py-5 shadow-md transition-transform hover:scale-105"
      >
        <div className="flex flex-col items-center">
          <Share2 className="w-8 h-8 mb-1" />
          <span className="text-lg font-bold">MY REFERRAL</span>
        </div>
      </Link>
    </div>
  );
}