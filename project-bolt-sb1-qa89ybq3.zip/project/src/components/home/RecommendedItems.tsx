import { MenuItem } from '../menu/MenuItem';
import { MenuItem as MenuItemType } from '../../types';
import { Link } from 'react-router-dom';
import { ChevronRight } from 'lucide-react';

interface RecommendedItemsProps {
  title: string;
  items: MenuItemType[];
  link?: string;
}

export function RecommendedItems({ title, items, link }: RecommendedItemsProps) {
  if (items.length === 0) {
    return null;
  }

  return (
    <div className="mb-8">
      <div className="flex justify-between items-center mb-3">
        <h2 className="text-lg font-bold">{title}</h2>
        {link && (
          <Link to={link} className="text-primary-600 text-sm flex items-center">
            More <ChevronRight className="w-4 h-4 ml-1" />
          </Link>
        )}
      </div>
      <div className="grid grid-cols-2 gap-4">
        {items.map((item) => (
          <MenuItem key={item.id} item={item} />
        ))}
      </div>
    </div>
  );
}