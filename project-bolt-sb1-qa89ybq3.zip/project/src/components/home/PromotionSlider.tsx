import { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Promotion } from '../../types';
import { cn } from '../../utils/cn';

interface PromotionSliderProps {
  promotions: Promotion[];
}

export function PromotionSlider({ promotions }: PromotionSliderProps) {
  const [activeIndex, setActiveIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveIndex((current) => (current + 1) % promotions.length);
    }, 5000);
    
    return () => clearInterval(interval);
  }, [promotions.length]);

  const goToPrevious = () => {
    setActiveIndex((current) => (current === 0 ? promotions.length - 1 : current - 1));
  };

  const goToNext = () => {
    setActiveIndex((current) => (current + 1) % promotions.length);
  };

  if (promotions.length === 0) {
    return null;
  }

  return (
    <div className="relative w-full h-48 overflow-hidden rounded-lg">
      <div 
        className="absolute inset-0 flex transition-transform duration-500 ease-in-out"
        style={{ transform: `translateX(-${activeIndex * 100}%)` }}
      >
        {promotions.map((promotion, index) => (
          <div key={promotion.id} className="min-w-full h-full relative">
            <img 
              src={promotion.image} 
              alt={promotion.title} 
              className="w-full h-full object-cover brightness-75"
            />
            <div className="absolute inset-0 flex flex-col justify-end p-4 text-white">
              <h3 className="text-xl font-bold">{promotion.title}</h3>
              <p className="text-sm">{promotion.description}</p>
              <div className="mt-2 bg-primary-600 text-white text-xs px-2 py-1 rounded-full inline-block w-fit">
                {promotion.discountPercentage}% OFF
              </div>
            </div>
          </div>
        ))}
      </div>
      
      <button 
        className="absolute left-2 top-1/2 transform -translate-y-1/2 bg-white/80 rounded-full p-1 shadow-md"
        onClick={goToPrevious}
        aria-label="Previous promotion"
      >
        <ChevronLeft className="w-5 h-5 text-neutral-700" />
      </button>
      
      <button 
        className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-white/80 rounded-full p-1 shadow-md"
        onClick={goToNext}
        aria-label="Next promotion"
      >
        <ChevronRight className="w-5 h-5 text-neutral-700" />
      </button>
      
      <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 flex space-x-1">
        {promotions.map((_, index) => (
          <button
            key={index}
            className={cn(
              'w-2 h-2 rounded-full transition-colors',
              index === activeIndex ? 'bg-white' : 'bg-white/50'
            )}
            onClick={() => setActiveIndex(index)}
            aria-label={`Go to promotion ${index + 1}`}
          />
        ))}
      </div>
    </div>
  );
}