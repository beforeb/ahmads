import { useEffect, useState } from 'react';
import { MenuItem } from './MenuItem';
import { Beef, ChefHat, Coffee, UtensilsCrossed, Sandwich } from 'lucide-react';
import { MenuCategory as MenuCategoryType, MenuItem as MenuItemType } from '../../types';
import { getMenuByCategory } from '../../data/menu';
import { cn } from '../../utils/cn';

interface MenuCategoryProps {
  category: MenuCategoryType;
  activeCategory: string;
  setActiveCategory: (id: string) => void;
}

export function MenuCategoryTab({ category, activeCategory, setActiveCategory }: MenuCategoryProps) {
  const isActive = category.id === activeCategory;
  
  // Map category icons
  const getCategoryIcon = () => {
    switch (category.icon) {
      case 'Beef':
        return <Beef className="w-5 h-5" />;
      case 'Drumstick':
        return <ChefHat className="w-5 h-5" />;
      case 'UtensilsCrossed':
        return <UtensilsCrossed className="w-5 h-5" />;
      case 'Coffee':
        return <Coffee className="w-5 h-5" />;
      case 'Sandwich':
        return <Sandwich className="w-5 h-5" />;
      default:
        return <Beef className="w-5 h-5" />;
    }
  };

  return (
    <button
      className={cn(
        'flex flex-col items-center p-3 border rounded-lg transition-all',
        {
          'border-primary-500 bg-primary-50 text-primary-700': isActive,
          'border-gray-200 hover:bg-gray-50': !isActive,
        }
      )}
      onClick={() => setActiveCategory(category.id)}
    >
      <div
        className={cn('p-2 rounded-full mb-1', {
          'bg-primary-100': isActive,
          'bg-gray-100': !isActive,
        })}
      >
        {getCategoryIcon()}
      </div>
      <span className="text-xs font-medium">{category.name}</span>
    </button>
  );
}

interface MenuCategoryListProps {
  categoryId: string;
}

export function MenuCategoryList({ categoryId }: MenuCategoryListProps) {
  const [items, setItems] = useState<MenuItemType[]>([]);

  useEffect(() => {
    setItems(getMenuByCategory(categoryId));
  }, [categoryId]);

  if (items.length === 0) {
    return <p className="text-center text-gray-500 my-4">No items found in this category.</p>;
  }

  return (
    <div className="grid grid-cols-2 gap-4 mt-4">
      {items.map((item) => (
        <MenuItem key={item.id} item={item} />
      ))}
    </div>
  );
}