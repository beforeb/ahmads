import { Card, CardImage, CardContent, CardTitle, CardDescription } from '../ui/Card';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { PlusCircle } from 'lucide-react';
import { MenuItem as MenuItemType } from '../../types';
import { Link } from 'react-router-dom';

interface MenuItemProps {
  item: MenuItemType;
}

export function MenuItem({ item }: MenuItemProps) {
  const { id, name, description, price, discountPrice, image, isNew, isPopular } = item;

  return (
    <Card className="h-full transition-all duration-300 hover:shadow-lg">
      <Link to={`/menu/item/${id}`}>
        <CardImage src={image} alt={name} className="h-40" />
        <CardContent className="p-3">
          <div className="flex justify-between items-start mb-2">
            <CardTitle className="text-base">{name}</CardTitle>
            <div className="flex flex-col items-end">
              {discountPrice ? (
                <>
                  <span className="text-primary-600 font-bold">RM {discountPrice.toFixed(2)}</span>
                  <span className="text-neutral-400 text-xs line-through">RM {price.toFixed(2)}</span>
                </>
              ) : (
                <span className="text-primary-600 font-bold">RM {price.toFixed(2)}</span>
              )}
            </div>
          </div>
          <CardDescription className="text-xs h-10 overflow-hidden mb-2">
            {description}
          </CardDescription>
          <div className="flex justify-between items-center">
            <div className="flex gap-1">
              {isNew && <Badge variant="error" size="sm">New</Badge>}
              {isPopular && <Badge variant="primary" size="sm">Popular</Badge>}
            </div>
            <Button size="sm" className="rounded-full w-8 h-8 p-0 flex items-center justify-center">
              <PlusCircle className="w-5 h-5" />
            </Button>
          </div>
        </CardContent>
      </Link>
    </Card>
  );
}