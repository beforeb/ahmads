import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Home, Menu as MenuIcon, ClipboardList, User, ShoppingCart } from 'lucide-react';
import { cn } from '../../utils/cn';
import { useCartStore } from '../../store/cartStore';

export function Navbar() {
  const location = useLocation();
  const cart = useCartStore(state => state.cart);
  const cartItemCount = cart.items.reduce((total, item) => total + item.quantity, 0);

  const navItems = [
    {
      label: 'Home',
      icon: <Home className="w-6 h-6" />,
      href: '/',
    },
    {
      label: 'Menu',
      icon: <MenuIcon className="w-6 h-6" />,
      href: '/menu',
    },
    {
      label: 'Orders',
      icon: <ClipboardList className="w-6 h-6" />,
      href: '/orders',
    },
    {
      label: 'Account',
      icon: <User className="w-6 h-6" />,
      href: '/account',
    },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-10">
      <div className="grid grid-cols-4 py-2">
        {navItems.map((item) => (
          <Link
            key={item.href}
            to={item.href}
            className={cn(
              'flex flex-col items-center justify-center px-4 py-2',
              {
                'text-primary-600': location.pathname === item.href,
                'text-neutral-400 hover:text-neutral-700': location.pathname !== item.href,
              }
            )}
          >
            {item.icon}
            <span className="text-xs mt-1">{item.label}</span>
          </Link>
        ))}
      </div>
    </div>
  );
}

export function TopBar({ title }: { title?: string }) {
  const cartItemCount = useCartStore(state => 
    state.cart.items.reduce((total, item) => total + item.quantity, 0)
  );

  return (
    <div className="fixed top-0 left-0 right-0 bg-white border-b border-gray-200 z-10">
      <div className="flex items-center justify-between px-4 py-2">
        <div className="flex items-center">
          <Link to="/" className="flex items-center">
            <span className="text-primary-600 text-xl font-bold">Ahmads+</span>
          </Link>
        </div>
        {title && <h1 className="text-lg font-semibold">{title}</h1>}
        <div className="flex items-center">
          <Link to="/cart" className="relative p-2">
            <ShoppingCart className="w-6 h-6 text-neutral-700" />
            {cartItemCount > 0 && (
              <span className="absolute top-0 right-0 inline-flex items-center justify-center w-5 h-5 bg-primary-600 text-white text-xs font-bold rounded-full">
                {cartItemCount}
              </span>
            )}
          </Link>
        </div>
      </div>
    </div>
  );
}