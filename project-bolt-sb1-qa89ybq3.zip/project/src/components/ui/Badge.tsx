import { HTMLAttributes, ReactNode } from 'react';
import { cn } from '../../utils/cn';

interface BadgeProps extends HTMLAttributes<HTMLSpanElement> {
  children: ReactNode;
  variant?: 'primary' | 'secondary' | 'success' | 'warning' | 'error' | 'outline';
  size?: 'sm' | 'md' | 'lg';
}

export function Badge({
  className,
  variant = 'primary',
  size = 'md',
  children,
  ...props
}: BadgeProps) {
  return (
    <span
      className={cn(
        'inline-flex items-center justify-center rounded-full font-medium',
        {
          'bg-primary-100 text-primary-800': variant === 'primary',
          'bg-secondary-100 text-secondary-800': variant === 'secondary',
          'bg-success-100 text-success-600': variant === 'success',
          'bg-warning-100 text-warning-600': variant === 'warning',
          'bg-error-100 text-error-600': variant === 'error',
          'bg-white border border-neutral-300 text-neutral-700': variant === 'outline',
          'px-2 py-0.5 text-xs': size === 'sm',
          'px-2.5 py-0.5 text-sm': size === 'md',
          'px-3 py-1 text-base': size === 'lg',
        },
        className
      )}
      {...props}
    >
      {children}
    </span>
  );
}