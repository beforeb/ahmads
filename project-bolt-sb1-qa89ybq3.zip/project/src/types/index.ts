// User types
export interface User {
  id: string;
  email: string;
  name: string;
  phone?: string;
  points: number;
  referralCode: string;
  referredBy?: string;
  checkInDates: string[];
}

// Auth types
export interface AuthState {
  user: User | null;
  isLoading: boolean;
  error: string | null;
}

// Menu types
export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  discountPrice?: number;
  image: string;
  category: string;
  isPopular?: boolean;
  isNew?: boolean;
  options?: MenuItemOption[];
}

export interface MenuItemOption {
  id: string;
  name: string;
  choices: {
    id: string;
    name: string;
    price: number;
  }[];
}

export interface MenuCategory {
  id: string;
  name: string;
  icon: string;
}

// Cart types
export interface CartItem {
  id: string;
  menuItemId: string;
  name: string;
  price: number;
  quantity: number;
  image: string;
  selectedOptions: {
    optionId: string;
    choiceId: string;
    name: string;
    choiceName: string;
    price: number;
  }[];
}

export interface Cart {
  items: CartItem[];
  orderType: 'dine-in' | 'delivery';
  tableNumber?: string;
  deliveryAddress?: Address;
  outlet: Outlet | null;
  subtotal: number;
  discount: number;
  total: number;
}

// Location types
export interface Address {
  id?: string;
  title: string;
  fullAddress: string;
  latitude: number;
  longitude: number;
  isDefault?: boolean;
}

export interface Outlet {
  id: string;
  name: string;
  address: string;
  latitude: number;
  longitude: number;
  distance?: number;
  isOpen: boolean;
  openingHours: string;
}

// Order types
export interface Order {
  id: string;
  userId: string;
  items: CartItem[];
  outlet: Outlet;
  orderType: 'dine-in' | 'delivery';
  tableNumber?: string;
  deliveryAddress?: Address;
  status: 'preparing' | 'ready' | 'delivering' | 'completed';
  totalAmount: number;
  pointsEarned: number;
  pointsUsed: number;
  paymentMethod: string;
  createdAt: string;
}

// Reward types
export interface Reward {
  id: string;
  name: string;
  description: string;
  pointsCost: number;
  image: string;
  expiryDate?: string;
}

// Promotion types
export interface Promotion {
  id: string;
  title: string;
  description: string;
  image: string;
  discountPercentage: number;
  validUntil: string;
  itemIds?: string[];
  categoryIds?: string[];
  minimumSpend?: number;
}